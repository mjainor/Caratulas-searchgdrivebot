# Que hace el bot?
Busca archivos en carpetas que tu elijas o en un Team drive completo

# Cuales son los pasos a seguir?


# [AQUI EL TUTORIAL con pasos y video ❤](https://uniq.edu.mx/Telegram-bot-para-buscar-archivos-dentro-de-un-team-drive-o-carpetas-en-google-drive)


Bot telegram el cual nos permitira buscar archivos dentro de una carpeta o team drive de forma recursiva, arrojandonos el resultado en una pagina de telegraph

### Lo que necesitamos para elaborar este bot es:
- **OWNER_ID**: El ID de tu Cuenta telegram
-  **ID** de grupo telegram (si lo quieres compartir con tus amigos y ellos puedan buscar tambien; si solo lo usaras tu no lo necesitas)
- **BOT_TOKEN** : el token del bot que usaras
- **TELEGRAPH_TOKEN** : un token de telegram
- **ID** De tu Team Drive (unidad compartida gdrive o folder id)
- **credentials.json** Las credenciales de tu proyecto google console
- **token.pickle** El token de tu proyecto google Console
- Cuenta en *Heroku* y en *Replit* si no te la creas mas abajo.

## Proceso o tutorial a seguir paso a paso.

### Obtener *credentials.json* 
- Ir a [Google console](https://console.cloud.google.com/)
- Crear un nuevo proyecto
- Ir a pantalla de consentimiento, ponerle externo
- Tipo de app de escritorio
- Ir a Credenciales > Crear credenciales tipo OAuth
- Descargar las credenciales y renombrarlas a credentials.json

### Obtener token.pickle TELEGRAPH_TOKEN 

- Ir [Replit](https://replit.com/) 
- Colocar el repositorio 
- Instalar requerimientos con
```
pip install -r requirements.txt
```
- Generar token
```
python3 generate_drive_token.py
```
- Generar telegraph token
```
python3 telegraph_token.py
```
_introduce tu **username** de telegram_

Guardalo en el archivo tokentelegraph.txt

### Agregar el ID del Team Drive o carpeta donde se buscara la informacion 

```
python3 driveid.py
```
### Obtener *OWNER_ID* *BOT_TOKEN* 
- **OWNER_ID** : busca en telegram @userinfobot y dale /start y /id copia el ID
- **BOT_TOKEN** : Create un nuevo bot en telegram y obten tu token :)


### Opcional usar el bot en un  grupo
Si vas a compartir este bot para que alguien mas busque en tu Team Drive entonces debes crearte un grupo de telegram y obtener su ID , agregando al grupo creado el bot con permisos de administrador

Agrega el ID de tu grupo en el archivo llamado **authorized_chats.txt**

### Descargar los archivos necesarios de Replit y subirlos al fork
En replit descargaras lo necesario en un zip con

```
zip -r Drive-Search-Bot.zip credentials.json token.pickle authorized_chats.txt tokentelegraph.txt drive_folder
```

## Deploying a Heroku
_Dale click en el boton de abajo y te enviara a heroku_
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?)

### Rellena los datos en heroku
- Ve  RESOURCES y activa Free Dynos
- ve a tu bot y dale
```
/find ARCHIVO a buscar
```
